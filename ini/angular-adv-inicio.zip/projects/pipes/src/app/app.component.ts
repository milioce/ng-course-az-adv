import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <demo-pipe></demo-pipe>
  `,
  styles: []
})
export class AppComponent {
  title = 'pipes';
}
