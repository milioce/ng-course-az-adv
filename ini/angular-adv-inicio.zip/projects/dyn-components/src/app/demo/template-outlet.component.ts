import { Component } from '@angular/core';

@Component({
  selector: 'app-template-outlet',
  template: `
  `
})

export class TemplateOutletComponent {
}
