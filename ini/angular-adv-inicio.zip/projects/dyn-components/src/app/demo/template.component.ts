import { Component } from '@angular/core';

@Component({
  selector: 'app-template',
  template: `
    <div #entry></div>
  `
})

export class TemplateComponent {
}
