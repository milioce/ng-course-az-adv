import { Directive } from '@angular/core';

@Directive({ selector: '[myFor]' })
export class MyForDirective {
  constructor() { }
}
