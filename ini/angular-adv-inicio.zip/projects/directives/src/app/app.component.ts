import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <demo-credit-card></demo-credit-card>
  `,
  styles: [``]
})
export class AppComponent {
  title = 'directives';
}
