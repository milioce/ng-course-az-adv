import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <app-food></app-food>
  `,
  styles: []
})
export class AppComponent {
  title = 'services';
}
