export interface Mail {
  folder: string,
  from: string,
  id: number,
  summary: string,
  timestamp: number
}