import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  template: `
    <div>
      <h1>Dashboard</h1>
    </div>
  `
})

export class DashboardComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
